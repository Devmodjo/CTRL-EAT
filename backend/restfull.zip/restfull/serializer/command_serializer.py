from rest_framework import serializers
from ..models.commande_models import Commande

class CommandSerializer(serializers.ModelSerializer):
    class Meta:
        model = Commande
        fields = '__all__'
        read_only_fields = ['id', 'date_creation']