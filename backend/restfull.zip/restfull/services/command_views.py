from rest_framework import generics
from ..serializer.command_serializer import CommandSerializer
from ..models.commande_models import Commande

class CommandListCreateView(generics.ListCreateAPIView):
    queryset  = Commande.objects.all()
    serializer_class = CommandSerializer
    
class CommandRetreiveUpdateDestroyView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Commande.objects.all()
    serializer_class = CommandSerializer
    lookup_field = 'id'